﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TownOfUs.Extensions
{
    public enum CustomPlayerOutfitType 
    {
        Default,
        Shapeshifted,
        Morph,
        Camouflage,
        Swooper,
        PlayerNameOnly

    }
}
