namespace TownOfUs
{
    public enum RoleEnum
    {
        Sheriff,
        Jester,
        Lover,
        LoverImpostor,
        Engineer,
        Mayor,
        Swapper,
        Investigator,
        TimeLord,
        Shifter,
        Medic,
        Seer,
        Executioner,
        Spy,
        Snitch,
        Arsonist,
        Altruist,
        Phantom,
        Retributionist,
        Haunter,

        Miner,
        Swooper,
        Morphling,
        Camouflager,
        Janitor,
        Undertaker,
        Assassin,
        Underdog,
        Grenadier,


        Glitch,

        Crewmate,
        Impostor,
        None
    }

    public enum ModifierEnum
    {
        Torch,
        Diseased,
        Flash,
        Tiebreaker,
        Drunk,
        BigBoi,
        ButtonBarry
    }
}
