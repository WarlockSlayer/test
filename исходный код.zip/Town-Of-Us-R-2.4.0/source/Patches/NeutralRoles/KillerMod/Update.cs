﻿using System.Linq;
using HarmonyLib;
using InnerNet;
using TownOfUs.Roles;

namespace TownOfUs.NeutralRoles.KillerMod
{
    [HarmonyPatch(typeof(HudManager), nameof(HudManager.Update))]
    internal class Update
    {
        private static void Postfix(HudManager __instance)
        {
            var glitch = Role.AllRoles.FirstOrDefault(x => x.RoleType == RoleEnum.Killer);
            if (AmongUsClient.Instance.GameState == InnerNetClient.GameStates.Started)
                if (killer != null)
                    if (PlayerControl.LocalPlayer.Is(RoleEnum.Killer))
                        Role.GetRole<Killer>(PlayerControl.LocalPlayer).Update(__instance);
        }
    }
}