﻿using System;
using System.Linq;
using HarmonyLib;
using TownOfUs.Roles;
using Object = UnityEngine.Object;

namespace TownOfUs.NeutralRoles.KillerMod
{
    [HarmonyPatch(typeof(Object), nameof(Object.Destroy), typeof(Object))]
    internal class MeetingExiledEnd
    {
        private static void Prefix(Object obj)
        {
            if (ExileController.Instance != null && obj == ExileController.Instance.gameObject)
            {
                var killer = Role.AllRoles.FirstOrDefault(x => x.RoleType == RoleEnum.Killer);
                if (killer != null)
                {
                    ((Killer)killer).LastKill = DateTime.UtcNow;
                    ((Killer)killer).LastMimic = DateTime.UtcNow;
                    ((Killer)killer).LastHack = DateTime.UtcNow;
                }
            }
        }
    }
}