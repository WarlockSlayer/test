﻿using System;
using System.Linq;
using HarmonyLib;
using TownOfUs.Roles;

namespace TownOfUs.NeutralRoles.GlitchMod
{
    [HarmonyPatch(typeof(IntroCutscene._CoBegin_d__18), nameof(IntroCutscene._CoBegin_d__18.MoveNext))]
    internal class Start
    {
        private static void Postfix(IntroCutscene._CoBegin_d__18 __instance)
        {
            var glitch = Role.AllRoles.FirstOrDefault(x => x.RoleType == RoleEnum.Glitch);
            if (glitch != null)
            {
                
                ((Glitch)glitch).LastHack = DateTime.UtcNow.AddSeconds(CustomGameOptions.InitialCooldowns + CustomGameOptions.HackCooldown * -1);
               
            }
        }
    }
}